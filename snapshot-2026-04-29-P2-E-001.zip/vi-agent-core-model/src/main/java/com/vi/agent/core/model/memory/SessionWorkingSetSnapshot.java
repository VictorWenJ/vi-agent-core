package com.vi.agent.core.model.memory;

import lombok.Builder;
import lombok.Getter;
import lombok.Singular;
import lombok.extern.jackson.Jacksonized;

import java.time.Instant;
import java.util.List;

/**
 * 最近 completed raw transcript 工作集快照。
 */
@Getter
@Builder
@Jacksonized
public class SessionWorkingSetSnapshot {

    /** 当前 session ID。 */
    private final String sessionId;

    /** 会话所属 conversation ID。 */
    private final String conversationId;

    /** working set 版本。 */
    private final Long workingSetVersion;

    /** 当前配置下最多保留的 completed turn 数。 */
    private final Integer maxCompletedTurns;

    /** summary 已覆盖到的最高消息序号。 */
    private final Long summaryCoveredToSequenceNo;

    /** working set 内 raw message ID 列表。 */
    @Singular("rawMessageId")
    private final List<String> rawMessageIds;

    /** working set 更新时间。 */
    private final Instant updatedAt;
}
